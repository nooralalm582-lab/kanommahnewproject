/* =========================================================
   كن أمة — Script
   ========================================================= */
document.addEventListener('DOMContentLoaded', () => {

  /* ---------- Auth state (Supabase session) ---------- */
  (async function initAuthState() {
    if (typeof supabaseClient === 'undefined' || !supabaseClient) return;

    const headerBtn = document.getElementById('headerAuthBtn');
    const navLoginLink = document.getElementById('navLoginLink');
    if (!headerBtn && !navLoginLink) return; // not on a page with header/nav

    const { data: { session } } = await supabaseClient.auth.getSession();
    if (!session || !session.user) return;

    const fullName = session.user.user_metadata && session.user.user_metadata.full_name;
    const displayName = fullName || session.user.email.split('@')[0];

    if (navLoginLink) {
      navLoginLink.textContent = `مرحباً، ${displayName}`;
      navLoginLink.setAttribute('href', '#');
      navLoginLink.addEventListener('click', (e) => e.preventDefault());
    }
    if (headerBtn) {
      headerBtn.textContent = 'تسجيل الخروج';
      headerBtn.setAttribute('href', '#');
      headerBtn.addEventListener('click', async (e) => {
        e.preventDefault();
        await supabaseClient.auth.signOut();
        window.location.href = 'index.html';
      });
    }
  })();

  /* ---------- Sticky nav shadow on scroll ---------- */
  const siteNav = document.getElementById('siteNav');
  if (siteNav) {
    const onScroll = () => {
      siteNav.classList.toggle('is-scrolled', window.scrollY > 10);
    };
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
  }

  /* ---------- Mobile nav toggle ---------- */
  const navToggle = document.getElementById('navToggle');
  const navLinks = document.getElementById('navLinks');
  if (navToggle && navLinks) {
    navToggle.addEventListener('click', () => {
      const isOpen = navLinks.classList.toggle('open');
      navToggle.setAttribute('aria-expanded', String(isOpen));
      navToggle.innerHTML = isOpen
        ? '<i class="fa-solid fa-xmark"></i>'
        : '<i class="fa-solid fa-bars"></i>';
    });
    navLinks.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        navLinks.classList.remove('open');
        navToggle.setAttribute('aria-expanded', 'false');
        navToggle.innerHTML = '<i class="fa-solid fa-bars"></i>';
      });
    });
  }

  /* ---------- Active nav link highlighting on scroll (home page) ---------- */
  const sections = document.querySelectorAll('main section[id]');
  const navAnchors = document.querySelectorAll('.nav-links a[data-section]');
  if (sections.length && navAnchors.length) {
    const spy = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          const id = entry.target.id === 'heroSlider' ? 'home' : entry.target.id;
          navAnchors.forEach(a => a.classList.toggle('active', a.dataset.section === id));
        }
      });
    }, { rootMargin: '-45% 0px -50% 0px' });
    document.querySelectorAll('#heroSlider, #message').forEach(s => spy.observe(s));
  }

  /* ---------- Hero slider ---------- */
  const track = document.getElementById('heroTrack');
  if (track) {
    const slides = Array.from(track.children);
    const dotsWrap = document.getElementById('heroDots');
    const prevBtn = document.getElementById('heroPrev');
    const nextBtn = document.getElementById('heroNext');
    let index = 0;
    let timer = null;
    const AUTOPLAY_MS = 5500;

    slides.forEach((_, i) => {
      const dot = document.createElement('button');
      dot.type = 'button';
      dot.role = 'tab';
      dot.setAttribute('aria-label', `الشريحة ${i + 1}`);
      if (i === 0) dot.classList.add('active');
      dot.addEventListener('click', () => goTo(i, true));
      dotsWrap.appendChild(dot);
    });
    const dots = Array.from(dotsWrap.children);

    function render() {
      track.style.transform = `translateX(${-index * 100}%)`;
      slides.forEach((s, i) => s.classList.toggle('is-active', i === index));
      dots.forEach((d, i) => d.classList.toggle('active', i === index));
    }

    function goTo(i, userTriggered) {
      index = (i + slides.length) % slides.length;
      render();
      if (userTriggered) restartAutoplay();
    }

    function next() { goTo(index + 1); }
    function prev() { goTo(index - 1); }

    function startAutoplay() {
      timer = setInterval(next, AUTOPLAY_MS);
    }
    function restartAutoplay() {
      clearInterval(timer);
      startAutoplay();
    }

    nextBtn.addEventListener('click', () => goTo(index + 1, true));
    prevBtn.addEventListener('click', () => goTo(index - 1, true));

    const heroSlider = document.getElementById('heroSlider');
    heroSlider.addEventListener('mouseenter', () => clearInterval(timer));
    heroSlider.addEventListener('mouseleave', startAutoplay);
    heroSlider.addEventListener('focusin', () => clearInterval(timer));
    heroSlider.addEventListener('focusout', startAutoplay);

    /* touch swipe */
    let startX = 0;
    track.addEventListener('touchstart', (e) => { startX = e.touches[0].clientX; }, { passive: true });
    track.addEventListener('touchend', (e) => {
      const diff = e.changedTouches[0].clientX - startX;
      if (Math.abs(diff) > 40) {
        diff > 0 ? goTo(index - 1, true) : goTo(index + 1, true);
      }
    }, { passive: true });

    /* keyboard arrows */
    heroSlider.setAttribute('tabindex', '0');
    heroSlider.addEventListener('keydown', (e) => {
      if (e.key === 'ArrowLeft') goTo(index + 1, true);
      if (e.key === 'ArrowRight') goTo(index - 1, true);
    });

    render();
    startAutoplay();

    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      clearInterval(timer);
    }
  }

  /* ---------- Reveal on scroll ---------- */
  const revealEls = document.querySelectorAll('.reveal, .reveal-stagger');
  if (revealEls.length) {
    const io = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          io.unobserve(entry.target);
        }
      });
    }, { threshold: 0.15 });
    revealEls.forEach(el => io.observe(el));
  }

  /* ---------- Login page ---------- */
  const loginForm = document.getElementById('loginForm');
  if (loginForm) {
    const togglePassword = document.getElementById('togglePassword');
    const passwordInput = document.getElementById('password');
    const toggleIcon = document.getElementById('toggleIcon');

    togglePassword.addEventListener('click', () => {
      const isHidden = passwordInput.type === 'password';
      passwordInput.type = isHidden ? 'text' : 'password';
      toggleIcon.classList.toggle('fa-eye', !isHidden);
      toggleIcon.classList.toggle('fa-eye-slash', isHidden);
      togglePassword.setAttribute('aria-pressed', String(isHidden));
      togglePassword.setAttribute('aria-label', isHidden ? 'إخفاء كلمة المرور' : 'إظهار كلمة المرور');
    });

    const toast = document.getElementById('toast');
    let toastTimer = null;
    function showToast(message) {
      toast.textContent = message;
      toast.classList.add('show');
      clearTimeout(toastTimer);
      toastTimer = setTimeout(() => toast.classList.remove('show'), 3200);
    }

    function showError(fieldId, errorId, message) {
      const field = document.getElementById(fieldId);
      const error = document.getElementById(errorId);
      error.textContent = message;
      field.classList.remove('shake');
      // force reflow to restart animation
      void field.offsetWidth;
      field.classList.add('shake');
    }
    function clearError(fieldId, errorId) {
      document.getElementById(errorId).textContent = '';
      document.getElementById(fieldId).classList.remove('shake');
    }

    loginForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      let valid = true;
      const email = document.getElementById('email').value.trim();
      const password = passwordInput.value;
      const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

      if (!emailPattern.test(email)) {
        showError('emailField', 'emailError', 'يرجى إدخال بريد إلكتروني صحيح');
        valid = false;
      } else {
        clearError('emailField', 'emailError');
      }

      if (password.length < 6) {
        showError('passwordField', 'passwordError', 'كلمة المرور يجب أن تكون 6 أحرف على الأقل');
        valid = false;
      } else {
        clearError('passwordField', 'passwordError');
      }

      if (!valid) return;

      if (typeof supabaseClient === 'undefined' || !supabaseClient) {
        showToast('النظام غير مهيأ بعد. أضف بيانات مشروع Supabase في ملف config.js');
        return;
      }

      const submitBtn = loginForm.querySelector('button[type="submit"]');
      const originalLabel = submitBtn.textContent;
      submitBtn.disabled = true;
      submitBtn.textContent = 'جاري الدخول...';

      const { error } = await supabaseClient.auth.signInWithPassword({ email, password });

      submitBtn.disabled = false;
      submitBtn.textContent = originalLabel;

      if (error) {
        showError('passwordField', 'passwordError', 'البريد الإلكتروني أو كلمة المرور غير صحيحة');
        return;
      }

      showToast('تم تسجيل الدخول بنجاح، أهلاً بك من جديد!');
      loginForm.reset();
      setTimeout(() => { window.location.href = 'index.html'; }, 1200);
    });

    [['email', 'emailField', 'emailError'], ['password', 'passwordField', 'passwordError']]
      .forEach(([inputId, fieldId, errorId]) => {
        document.getElementById(inputId).addEventListener('input', () => clearError(fieldId, errorId));
      });
  }

  /* ---------- Signup page ---------- */
  const signupForm = document.getElementById('signupForm');
  if (signupForm) {
    const setupToggle = (toggleId, inputId, iconId) => {
      const toggleBtn = document.getElementById(toggleId);
      const input = document.getElementById(inputId);
      const icon = document.getElementById(iconId);
      toggleBtn.addEventListener('click', () => {
        const isHidden = input.type === 'password';
        input.type = isHidden ? 'text' : 'password';
        icon.classList.toggle('fa-eye', !isHidden);
        icon.classList.toggle('fa-eye-slash', isHidden);
        toggleBtn.setAttribute('aria-pressed', String(isHidden));
        toggleBtn.setAttribute('aria-label', isHidden ? 'إخفاء كلمة المرور' : 'إظهار كلمة المرور');
      });
    };
    setupToggle('toggleSignupPassword', 'signupPassword', 'toggleSignupIcon');
    setupToggle('toggleConfirmPassword', 'confirmPassword', 'toggleConfirmIcon');

    const toast = document.getElementById('toast');
    let toastTimer = null;
    function showToast(message) {
      toast.textContent = message;
      toast.classList.add('show');
      clearTimeout(toastTimer);
      toastTimer = setTimeout(() => toast.classList.remove('show'), 3200);
    }

    function showError(fieldId, errorId, message) {
      const field = document.getElementById(fieldId);
      const error = document.getElementById(errorId);
      error.textContent = message;
      field.classList.remove('shake');
      void field.offsetWidth;
      field.classList.add('shake');
    }
    function clearError(fieldId, errorId) {
      document.getElementById(errorId).textContent = '';
      document.getElementById(fieldId).classList.remove('shake');
    }

    signupForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      let valid = true;

      const name = document.getElementById('fullName').value.trim();
      const email = document.getElementById('signupEmail').value.trim();
      const phone = document.getElementById('phone').value.trim();
      const password = document.getElementById('signupPassword').value;
      const confirm = document.getElementById('confirmPassword').value;
      const terms = document.getElementById('terms').checked;
      const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

      if (name.length < 2) {
        showError('nameField', 'nameError', 'يرجى إدخال الاسم الكامل');
        valid = false;
      } else {
        clearError('nameField', 'nameError');
      }

      if (!emailPattern.test(email)) {
        showError('signupEmailField', 'signupEmailError', 'يرجى إدخال بريد إلكتروني صحيح');
        valid = false;
      } else {
        clearError('signupEmailField', 'signupEmailError');
      }

      if (password.length < 6) {
        showError('signupPasswordField', 'signupPasswordError', 'كلمة المرور يجب أن تكون 6 أحرف على الأقل');
        valid = false;
      } else {
        clearError('signupPasswordField', 'signupPasswordError');
      }

      if (confirm !== password || confirm.length === 0) {
        showError('confirmField', 'confirmError', 'كلمتا المرور غير متطابقتين');
        valid = false;
      } else {
        clearError('confirmField', 'confirmError');
      }

      const termsError = document.getElementById('termsError');
      if (!terms) {
        termsError.textContent = 'يجب الموافقة على الشروط والأحكام للمتابعة';
        valid = false;
      } else {
        termsError.textContent = '';
      }

      if (!valid) return;

      if (typeof supabaseClient === 'undefined' || !supabaseClient) {
        showToast('النظام غير مهيأ بعد. أضف بيانات مشروع Supabase في ملف config.js');
        return;
      }

      const submitBtn = signupForm.querySelector('button[type="submit"]');
      const originalLabel = submitBtn.textContent;
      submitBtn.disabled = true;
      submitBtn.textContent = 'جاري الإنشاء...';

      const { error } = await supabaseClient.auth.signUp({
        email,
        password,
        options: { data: { full_name: name, phone: phone || null } }
      });

      submitBtn.disabled = false;
      submitBtn.textContent = originalLabel;

      if (error) {
        const isDuplicate = /registered|exists/i.test(error.message);
        showError(
          'signupEmailField',
          'signupEmailError',
          isDuplicate ? 'هذا البريد الإلكتروني مسجل بالفعل' : 'تعذّر إنشاء الحساب، حاول مرة أخرى'
        );
        return;
      }

      showToast('تم إنشاء حسابك بنجاح! تحقق من بريدك الإلكتروني لتأكيد الحساب إن لزم الأمر');
      signupForm.reset();
      setTimeout(() => { window.location.href = 'login.html'; }, 2200);
    });

    ['fullName', 'signupEmail', 'signupPassword', 'confirmPassword']
      .forEach(id => {
        document.getElementById(id).addEventListener('input', () => {
          const map = {
            fullName: ['nameField', 'nameError'],
            signupEmail: ['signupEmailField', 'signupEmailError'],
            signupPassword: ['signupPasswordField', 'signupPasswordError'],
            confirmPassword: ['confirmField', 'confirmError']
          };
          clearError(...map[id]);
        });
      });
    document.getElementById('terms').addEventListener('change', () => {
      document.getElementById('termsError').textContent = '';
    });
  }

});
